const loginSchema = require('./login.validator');
const registerSchema = require('./register.validator');

module.exports = { loginSchema, registerSchema };
export const initialRegistrationValue = {
    user_fname: '',
    user_lname: '',
    user_email: '',
    user_pass: '',
    user_confirmPassword: '',
    user_phone: '',
};

export const initialLogInValue = { user_email: "", user_pass: "" }
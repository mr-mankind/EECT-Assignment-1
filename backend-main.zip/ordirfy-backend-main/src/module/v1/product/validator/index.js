const productAddSchema = require('./product-add.validator')
const productGetSchema = require('./product.validator')
const productUpdateSchema = require('./product-update.validator')

module.exports = { productAddSchema, productGetSchema,productUpdateSchema }
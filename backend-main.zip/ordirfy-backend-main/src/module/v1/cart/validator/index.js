const cartAddSchema = require('./cart-add.validator');
const cartDelSchema = require('./cart-delete.validator');

module.exports = { cartAddSchema, cartDelSchema };